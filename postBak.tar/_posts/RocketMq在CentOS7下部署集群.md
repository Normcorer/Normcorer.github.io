title: RocketMq在CentOS7下部署集群
author: MolZhao
abbrlink: '12096768'
tags:
  - RocketMq
  - 消息队列
categories:
  - 互联网架构
date: 2020-11-17 10:18:00
---
## 前言

在运用中流程一般 是在程序中使用代码编辑生产者,将所需要的消息发送到rocketmq中，然后另一个程序编辑消费者从rocketmq里面获取消息。rocketmq集群，需要nameServer和Broker集群。

准备两台服务器，两台机器都是master，如果要搞一主N备，修改相应的配置文件

1.ip:192.168.31.144 rocketmq-nameserver1  rocketmq-master1

2.ip:192.168.31.165 rocketmq-nameserver2  rocketmq-master2
***

## 安装JDK环境
[点击此处下载JDK](https://www.oracle.com/technetwork/java/javase/downloads/index.html)

![reouces1](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource1.png)

1.上传该文件到：`/usr/local`

2.解压 `tar -zxvf jdk-7u80-linux-x64.tar.gz`

3.修改配置文件

4.`vi /etc/profile `

![reouces2](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource2.png)

在末尾添加配置文件：

```bash
export JAVA_HOME=/usr/local/jdk1.7.0_80
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$PATH
```

刷新配置文件：

`source /etc/profile`（该命令可以让 当前的配置文件立刻生效。不需要在重启服务器）

5.测试jdk安装是否成功： java -version
```bash
java -version
java version "1.8.0_131"
Java(TM) SE Runtime Environment (build 1.8.0_131-b11)
Java HotSpot(TM) 64-Bit Server VM (build 25.131-b11, mixed mode)
```
如上所示：表示成功。
***

## 配置RocketMQ集群
1.[点击此处下载mq](http://rocketmq.apache.org/dowloading/releases/)

2.上传下载包到 `/usr/local`

3.解压文件 
``` bash
# 上传alibaba-rocketmq-3.2.6.tar.gz文件至/usr/local
# tar -zxvf alibaba-rocketmq-3.2.6.tar.gz -C /usr/local
# mv alibaba-rocketmq alibaba-rocketmq-3.2.6
# ln -s alibaba-rocketmq-3.2.6 rocketmq
```
4.创建存储路径：
``` bash
mkdir /usr/local/rocketmq/store
# mkdir /usr/local/rocketmq/store/commitlog
# mkdir /usr/local/rocketmq/store/consumequeue
# mkdir /usr/local/rocketmq/store/index
```
5.修改rocketmq的核心配置文件：

**broker-a.properties文件配置**
```bash
#所属集群名字
brokerClusterName=rocketmq-cluster
#broker名字，注意此处不同的配置文件填写的不一样
brokerName=broker-a
#0 表示 Master，>0 表示 Slave
brokerId=0
#nameServer地址，分号分割
namesrvAddr=rocketmq-nameserver1:9876;rocketmq-nameserver2:9876
#在发送消息时，自动创建服务器不存在的topic，默认创建的队列数
defaultTopicQueueNums=4
#是否允许 Broker 自动创建Topic，建议线下开启，线上关闭
autoCreateTopicEnable=true
#是否允许 Broker 自动创建订阅组，建议线下开启，线上关闭
autoCreateSubscriptionGroup=true
#Broker 对外服务的监听端口
listenPort=10911
#删除文件时间点，默认凌晨 4点
deleteWhen=04
#文件保留时间，默认 48 小时
fileReservedTime=120
#commitLog每个文件的大小默认1G
mapedFileSizeCommitLog=1073741824
#ConsumeQueue每个文件默认存30W条，根据业务情况调整
mapedFileSizeConsumeQueue=300000
#destroyMapedFileIntervalForcibly=120000
#redeleteHangedFileInterval=120000
#检测物理文件磁盘空间
diskMaxUsedSpaceRatio=88
#存储路径
storePathRootDir=/usr/local/rocketmq/store
#commitLog 存储路径
storePathCommitLog=/usr/local/rocketmq/store/commitlog
#消费队列存储路径存储路径
storePathConsumeQueue=/usr/local/rocketmq/store/consumequeue
#消息索引存储路径
storePathIndex=/usr/local/rocketmq/store/index
#checkpoint 文件存储路径
storeCheckpoint=/usr/local/rocketmq/store/checkpoint
#abort 文件存储路径
abortFile=/usr/local/rocketmq/store/abort
#限制的消息大小
maxMessageSize=65536
#flushCommitLogLeastPages=4
#flushConsumeQueueLeastPages=2
#flushCommitLogThoroughInterval=10000
#flushConsumeQueueThoroughInterval=60000
#Broker 的角色
#- ASYNC_MASTER 异步复制Master
#- SYNC_MASTER 同步双写Master
#- SLAVE
brokerRole=ASYNC_MASTER
#刷盘方式
#- ASYNC_FLUSH 异步刷盘
#- SYNC_FLUSH 同步刷盘
flushDiskType=ASYNC_FLUSH
#checkTransactionMessageEnable=false
#发消息线程池数量
#sendMessageThreadPoolNums=128
#拉消息线程池数量
#pullMessageThreadPoolNums=128
```

**broker-b.properties文件配置**
```bash
#所属集群名字
brokerClusterName=rocketmq-cluster
#broker名字，注意此处不同的配置文件填写的不一样
brokerName=broker-b
#0 表示 Master，>0 表示 Slave
brokerId=0
#nameServer地址，分号分割
namesrvAddr=rocketmq-nameserver1:9876;rocketmq-nameserver2:9876
#在发送消息时，自动创建服务器不存在的topic，默认创建的队列数
defaultTopicQueueNums=4
#是否允许 Broker 自动创建Topic，建议线下开启，线上关闭
autoCreateTopicEnable=true
#是否允许 Broker 自动创建订阅组，建议线下开启，线上关闭
autoCreateSubscriptionGroup=true
#Broker 对外服务的监听端口
listenPort=10911
#删除文件时间点，默认凌晨 4点
deleteWhen=04
#文件保留时间，默认 48 小时
fileReservedTime=120
#commitLog每个文件的大小默认1G
mapedFileSizeCommitLog=1073741824
#ConsumeQueue每个文件默认存30W条，根据业务情况调整
mapedFileSizeConsumeQueue=300000
#destroyMapedFileIntervalForcibly=120000
#redeleteHangedFileInterval=120000
#检测物理文件磁盘空间
diskMaxUsedSpaceRatio=88
#存储路径
storePathRootDir=/usr/local/rocketmq/store
#commitLog 存储路径
storePathCommitLog=/usr/local/rocketmq/store/commitlog
#消费队列存储路径存储路径
storePathConsumeQueue=/usr/local/rocketmq/store/consumequeue
#消息索引存储路径
storePathIndex=/usr/local/rocketmq/store/index
#checkpoint 文件存储路径
storeCheckpoint=/usr/local/rocketmq/store/checkpoint
#abort 文件存储路径
abortFile=/usr/local/rocketmq/store/abort
#限制的消息大小
maxMessageSize=65536
#flushCommitLogLeastPages=4
#flushConsumeQueueLeastPages=2
#flushCommitLogThoroughInterval=10000
#flushConsumeQueueThoroughInterval=60000
#Broker 的角色
#- ASYNC_MASTER 异步复制Master
#- SYNC_MASTER 同步双写Master
#- SLAVE
brokerRole=ASYNC_MASTER
#刷盘方式
#- ASYNC_FLUSH 异步刷盘
#- SYNC_FLUSH 同步刷盘
flushDiskType=ASYNC_FLUSH
#checkTransactionMessageEnable=false
#发消息线程池数量
#sendMessageThreadPoolNums=128
#拉消息线程池数量
#pullMessageThreadPoolNums=128
```

6.在本地host文件中 添加域名解析

配置文件中：`namesrvAddr=rocketmq-nameserver1:9876;rocketmq-nameserver2:9876` 此地址需要域名解析:

1.打开 `hosts` 文件 `vi /etc/hosts `

2.添加对应的域名解析：
![reouces3](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource3.png)

至于划横线的地方，有的机器如果不添加 则可能在启动NameServer的时候会报错 提示没有主机名关联的地址。

![reouces4](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource4.png)

可以通过`hostname`命令，查看主机名字

![reouces5](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource5.png)

修改完配置以后 则需要刷新网卡：
```bash
service network restart
```

如果是虚拟机克隆出来的服务器,刷新网卡的时候 如果报错，则可以查看：
```bash
vi /etc/sysconfig/network-scripts/ifcfg-xxx 文件（每台机器名字可能不一样）
```

修改HWADDR的mac地址

mac地址可以两种方式查看：
![reouces6](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource6.png)

或者

![reouces7](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource7.png)

![reouces8](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource8.png)

有的机器没有HWADDR 这个配置名字，如果没有则添加上去。修改完配置以后 重新刷新网卡 `service network restart`，如果刷新还报错。可以尝试重新启动。

可以通过ping的方式 检测 hosts文件是否配置成功：

![reouces9](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource9.png)

以上上传和解压，修改本地hosts文件，刷新网卡，关闭防火墙等操作两台服务器都应该进行相应的操作，所有的操作完成了，则接下来就是启动rocketmq
***

## 关于NameServer和brok的启动

1.进入  `cd /usr/local/rocketmq/bin` 

2.`nohup sh mqnamesrv &` 后台启动nameServer 然后通过jps命令查看当前是否正常启动。

ps：第一次操作的时候，总是会在这里出错，启动的时候 提示：

![reouces10](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource10.png)

网上查了一大堆原因，也不知道是怎么回事，可以换 `sh mqnamesrv` 这种方式启动，如果有报错 则会打印报错日志，如果启动的时候如图所示：

![reouces11](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource11.png)

表示正常启动成功，当然这是前端启动方式，ctrl+c 就自然退出了，需要切换成后台启动形式：

![reouces12](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource12.png)

所以启动这里，你可以先后台启动,然后通过 `jps` 查看 是否启动成功，如果没有启动成功则前台方式启动，看看打印的错误日志。例如：

![reouces13](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource13.png)

成功启动以后 则能看到：

![reouces14](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource14.png)

如果启动的时候因为内存分配原因 导致无法启动成功，则需要修改配置文件：

```bash
vi /usr/local/rocketmq/bin/runbroker.sh 
```
![reouces15](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource15.png)

2.启动brokerServer

1.`cd /usr/local/rocketmq/bin`

2.`nohup sh mqbroker -c /usr/local/rocketmq/conf/2m-noslave/broker-a.properties >/dev/null 2>&1 &` （如果是另一台机器，则启动时候需要用到是 broker -b.properties文件）如图：

![reouces16](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource16.png)

两台机器都完成了上面的步骤，可以搭建一个rocketmq的后端管理系统

1.下载 tomcat（可以将tomcat放在两台服务器中的任何一台都可以了 tomcat 不需要集群）

2.下载rocketmq的后端管理平台所需要的war包

![reouces17](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource17.png)

3.将war包放到`tomcat/webapps`目录（启动或者重启tomcat的时候自动解压war包了）

![reouces18](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource18.png)

4.修改位于：`/usr/local/apache-tomcat-7.0.65/webapps/rocketmq-web-console/WEB-INF/classes`下的`config.properties`文件将集群的ip地址配置进去。

![reouces19](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource19.png)

![reouces20](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource20.png)

5.启动tomcat 输入请求地址栏：

http://192.168.31.197:8080/rocketmq-web-console/cluster/list.do

![reouces21](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-11-17/resource21.png)
***

> 如果有小伙伴，想要一起交流学习的，欢迎添加博主微信。

![weChat](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/Common/WeChat.png)