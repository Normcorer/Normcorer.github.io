title: 网络通信框架（1）---Mina
author: MolZhao
abbrlink: '55146056'
tags:
  - 高并发
  - Mina
categories:
  - 互联网架构
date: 2020-06-13 15:04:00
---
## 前言
因为公司需要重构一个老项目，老项目的网络通信框架用的是Mina，现在需要迁移到Netty实现，所以趁着空闲的时间学习一下Mina。

## Mina框架概述
Apache Mina是一个能够帮助用户开发高性能和高伸缩性网络应用程序的框架。它通过Java nio技术基于TCP/IP和UDP/IP协议提供了抽象的、事件驱动的、异步的API。
学习Mina，需要你已掌握Java IO,Java NIO,Java Socket,Java线程及并发库(java.util.concurrent包)知识。
Mina同时提供了网络通信的Server端、Client端的封装。
Mina的底层依赖的主要是Java NIO库，上层提供的是基于事件的异步接口。
![Mina架构](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-13/mina.png)

## Mina主要接口
| 包名        | 作用         
    | -------   | :-----:      
    | org.apache.mina.core.buffer      | 用于缓冲区的IoBuffer  
    | org.apache.mina.core.service org.apache.mina.transport.*      | 用于提供连接的service
    | org.apache.mina.core.session      | 用于提供两端状态的session
    | org.apache.mina.core.filterchain org.apache.mina.filter.*      | 用于拦截所有IO事件和请求的filter chain和各类拦截器（在IoService和IoHandler之间） 
    | org.apache.mina.handler.*      | 用于处理IO事件的handler 
    | org.apache.mina.core.future      | 用于实现异步IO操作的 future
    | org.apache.mina.core.polling.*      | 用于实现IO轮询的的polling
    | org.apache.mina.proxy.*      | 用于实现代理的proxy
    
![Mina工作流程](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-20/Mina%E6%95%B4%E4%BD%93%E7%BB%93%E6%9E%84.png)

<b>IoService:</b>
这个接口在一个线程上负责套接字的建立，拥有自己的 Selector，监听是否有连接被建立。
<b>IoProcessor:</b>
这个接口在另一个线程丧负责检查是否有数据在通道中读写，也就是说它也拥有自己的Selector，这是与我们使用Java NIO编码时的一个不同之处，通常在Java NIO编码中，我们都是使用一个Selector，也就是不区分IoService和IoProcessor两个功能接口，另外IoProcessor负责调用在IoService上的过滤器，并在过滤器链之后调用IoHandler
<b>IoAccepter:</b>
相当于网络应用程序中的服务器端
<b>IoConnector:</b>
相当于客户端
<b>IoSession:</b>   
当前客户端到服务器端的一个连接实例
<b>IoHandler:</b>
这个接口负责编写业务逻辑，也就是接收、发送数据的地方。这也是实际开发过程中需要用户自己编写的部分代码。
<b>IoFilter :</b>  
过滤器用于悬接通讯层接口与业务层接口，这个接口定义一组拦截器，这些拦截器可以包括日志输出、黑名单过滤、数据的编码（write 方向）与解码（read 方向）等功能，其中数据的 encode与 decode是最为重要的、也是你在使用 Mina时最主要关注的地方。
![Mina通信过程](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-20/%E5%AE%A2%E6%88%B7%E7%AB%AF%E9%80%9A%E4%BF%A1%E8%BF%87%E7%A8%8B.png)

服务端流程：
1. 通过SocketAcceptor 同客户端建立连接；
2. 连接建立之后 I/O的读写交给了I/O Processor线程，I/O Processor是多线程的；
3. 通过I/O Processor 读取的数据经过IoFilterChain里所有配置的IoFilter，IoFilter进行消息的过滤，格式的转换，在这个层面可以制定一些自定义的协议；
4. 最后IoFilter将数据交给 Handler  进行业务处理，完成了整个读取的过程；
写入过程也是类似，只是刚好倒过来，通过IoSession.write 写出数据，然后Handler进行写入的业务处理，处理完成后交给IoFilterChain，进行消息过滤和协议的转换，最后通过 I/O Processor 将数据写出到 socket 通道。
![Mina核心类图](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-20/Mina%E6%A0%B8%E5%BF%83%E7%B1%BB%E5%9B%BE.png)
