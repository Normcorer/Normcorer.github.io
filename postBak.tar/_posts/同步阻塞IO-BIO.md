title: 同步阻塞IO---BIO
author: MolZhao
abbrlink: 9a526a8e
tags: []
categories:
  - JAVA
date: 2020-06-21 22:21:00
---
## 概述
JavaBIO：同步阻塞（传统阻塞型），服务器实现模式为一个连接一个线程，即客户端有连接请求时服务器端需要启动一个线程进行处理，如果这个连接不做任何事情会造成不必要的线程开销，可以通过线程池机制改善（实现多个客户连接服务器）
![简单示意图](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-21/BIO%E7%AE%80%E5%8D%95%E7%A4%BA%E6%84%8F%E5%9B%BE.png)

BIO方式适用于连接数目比较小且固定的架构，这种方式对服务器资源要求比较高，并发局限于应用中，JDK1.4以前的唯一选择，但程序简单易理解。
<b>对BIO编程流程的梳理</b>
1. 服务器点启动一个ServerSocket
2. 客户端启动Socket对服务器进行通信，默认情况下服务器端需要对每个客户建立一个线程与之通讯
3. 客户端发出请求后，先咨询服务器是否有线程响应，如果没有则会等待，或者被拒绝
4. 如果有相应，客户端线程会等待请求结束后，再继续执行

## BIO应用实例
实例说明：
1. 使用BIO模型编写一个服务器端，监听8888端口，当有客户端连接时，就启动一个线程与之通讯。
2. 要求使用线程池机制改善，可以连接多个客户端
3. 服务器端可以接受客户端发送的数据（telnet 方式即可）。

```java
package xyz.molzhao.bio;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BIOServer {
    public static void main(String[] args) throws IOException {
        ExecutorService executors = Executors.newCachedThreadPool();
        //创建ServerSocket
        ServerSocket serverSocket = new ServerSocket(8888);
        System.out.println("服务器启动了");
        while (true) {
            System.out.println("线程信息ID=" + Thread.currentThread().getId() + "名字=" + Thread.currentThread().getName());
            //监听等待客户端连接
            System.out.println("等待连接.....");
            Socket accept = serverSocket.accept();
            System.out.println("连接到一个客户端");
            //创建一个线程
            executors.execute(() -> {
                hanlder(accept);
            });
        }

    }
    //编写一个Hanlder和客户端通信
    public static void hanlder(Socket socket) {
        try {
            System.out.println("线程信息ID=" + Thread.currentThread().getId() + "名字=" + Thread.currentThread().getName());
            byte[] bytes = new byte[1024];
            //通过socket 获取一个输入流
            InputStream inputStream = socket.getInputStream();
            //循环读取客户端发送的数
            while (true) {
                System.out.println("线程信息ID=" + Thread.currentThread().getId() + "名字=" + Thread.currentThread().getName());
                System.out.println("read.......");
                int read = inputStream.read(bytes);
                if (read != -1) {
                    System.out.println(new String(bytes, 0, read)); //输出客户端发送的数据
                } else {
                    break;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            System.out.println("关闭和Client的连接");
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

```
我们用WIN + R打开终端界面，开始连接我们写好的服务器
![telnet连接服务器](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-21/telnet%E8%BF%9E%E6%8E%A5.png)

连接好之后，按CTRL + ]进入发送字符串模式
![sendMsg](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-21/sendmsg1.png)

由于我们使用的是线程池，我们可以连接多个客户端，继续按上面的步骤在建立一个telnet的连接
![sendMsg2](https://molzhao-pic.oss-cn-beijing.aliyuncs.com/2020-06-21/sendmsg.png)
如下是我们的执行结果，我们可以一步骤一步骤的操作，我们可以发现线程在什么时候阻塞。
```
//结果
等待连接.....
线程信息ID=11名字=pool-1-thread-1
线程信息ID=11名字=pool-1-thread-1
read.......
hello world
线程信息ID=11名字=pool-1-thread-1
read.......
连接到一个客户端
线程信息ID=1名字=main
等待连接.....
线程信息ID=12名字=pool-1-thread-2
线程信息ID=12名字=pool-1-thread-2
read.......
hello world 2
线程信息ID=12名字=pool-1-thread-2
read.......
```
## BIO问题分析
1. 每个请求都需要建立独立的线程，与对应的客户端进行数据的Read ->业务处理 -> 数据Write。
2. 当并发数较大时，需要创建大量的线程来处理连接，系统资源占用较大。
3. 连接建立后，如果当前线程暂时没有数据可读就阻塞在Read操作上，造成线程资源的浪费