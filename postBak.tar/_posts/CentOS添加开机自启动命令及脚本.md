title: CentOS添加开机自启动命令及脚本
author: MolZhao
abbrlink: 7156016b
tags:
  - CentOS
  - Nginx
categories:
  - Linux
date: 2020-06-07 10:30:00
---
## 方案一
如果只是添加一条简单的开机启动命令：
```
chmod + x /etc/rc.d/rc.local
#将要执行的命令写到 /etc/rc.d/rc.local 这个文件中
#重新启动即可
reboot 
```

## 方案二
添加开机自启服务，在CentOS中添加开机自启动服务非常方便，只需要两条命令（以Nginx为例）
```
systemctl enable nginx.service #设置Nginx服务为自启动服务
systemctl start nginx.service  #设置Nginx服务
```

如果没有nginx.service附件需要自己添加，自定义服务文件，添加到系统服务通过Systemctl管理,如下服务文件实例
```
[Unit]:服务的说明
Description:描述服务
After:描述服务类别

[Service]服务运行参数的设置
Type=forking是后台运行的形式
ExecStart为服务的具体运行命令
ExecReload为重启命令
ExecStop为停止命令
PrivateTmp=True表示给服务分配独立的临时空间
注意：启动、重启、停止命令全部要求使用绝对路径
[Install]服务安装的相关设置，可设置为多用户
```
```
[Unit]
Description=nginx - high performance web server
After=network.target remote-fs.target nss-lookup.target

[Service]
Type=forking
ExecStart=/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
ExecReload=/usr/local/nginx/sbin/nginx -s reload
ExecStop=/usr/local/nginx/sbin/nginx -s stop

[Install]
WantedBy=multi-user.target
```
1. 保存目录，以754权限保存在/usr/lib/systemd/system
2. 设置开机自启动，在任意目录下执行 systemctl enable nginx.service

```
#启动nginx服务
systemctl start nginx.service
#设置开机自启动
systemctl enable nginx.service
#停止开机自启动
systemctl disable nginx.service
#查看服务当前状态
systemctl status nginx.service
#重新启动服务
systemctl restart nginx.service
#查看所有已启动的服务
systemctl list-units --type=service
```


## 方案三
添加开机自启脚本

在CentOS中添加脚本有两种常用的方法，首先添加nginx启动脚本
```
## processname: nginx

nginx=/usr/local/nginx/sbin/nginx
conf=/usr/local/nginx/conf/nginx.conf
case $1 in
start)
echo -n "Starting Nginx"
$nginx -c $conf
echo " done"
;;
stop)
echo -n "Stopping Nginx"
killall -9 nginx
echo " done"
;;
test)
$nginx -t -c $conf
;;
reload)
echo -n "Reloading Nginx"
ps auxww | grep nginx | grep master | awk '{print $2}' | xargs kill -HUP
echo " done"
;;
restart)
$0 stop
$0 start
;;
show)
ps -aux|grep nginx
;;
*)
echo -n "Usage: $0 {start|restart|reload|stop|test|show}"
;;
esac
```
赋予脚本可执行权限
```
chmod +x 脚本位置
chomod +x /etc/rc.d/rc.local
vi /etc/rc.d/rc.local #在该文件下末尾增加执行脚本文件命令即可
```

## 方案四
```
#将脚本移动到/etc/rc.d/init.d 目录下
mv /home/nginx.sh /etc/rc/d/init.d
#增加脚本可执行权限
chmod +x /etc/rc/d/init.d/nginx.sh
#添加脚本到开机自动启动项目中
cd /etc/rc.d/init.d
chkconfig --add nginx.sh
chkconfig nginx.sh on
```
